package spreadsheet;

/**
 * command interface.
 */
public interface Commands {
  void macro(SpreadSheet s);
}
